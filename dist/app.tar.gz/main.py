import flet as ft
import math

#main page
app_page = None


def main(page: ft.Page):
    global app_page
    app_page = page
    page.bgcolor="#FDFBF7"
    page.title = "HydroStatics Calculator"
    page.scroll = ft.ScrollMode.ADAPTIVE
    page.theme_mode = ft.ThemeMode.LIGHT
    page.padding = 30
    page.window.width=700
    page.window.height=850
    page.window.resizable=False
    page.window.center()

    shape_dropdown = ft.Dropdown(
            label = "Shapes Menu",
            options = [ 
                ft.dropdown.Option("Rectangular"),
                ft.dropdown.Option("Circular"),
                ft.dropdown.Option("Triangular")
            ],
        value="Rectangular",
        on_select=lambda e: update_ui(e)
        )

    fluid_dropdown = ft.Dropdown(
        label="Standard Fluid",
        options=[
            ft.dropdown.Option(key="1000",text= "Fresh Water = 1000kg/m^3"),
            ft.dropdown.Option(key="850",text= "Oil = 850kg/m^3"),
            ft.dropdown.Option(key ="1035",text= "Sea Water = 1035kg/m^3")]
            , value="1000",
                                                                
        width=250)

    custom_density = ft.TextField(label="Custom Density Override",hint_text="400",width=200)
    #rectangle width and height

    rectangle_width = ft.TextField(label="Enter Rectangle Width",hint_text="Ex. 10",visible=True)
    rectangle_height = ft.TextField(label="Enter Rectangle Height",hint_text="Ex.5",visible=True)

    #Circle values
    Circle_Radii = ft.TextField(label="Enter Circle Radius",hint_text="Ex. 8",visible=False)

    #triangle base and height
    triangle_base = ft.TextField(label="Enter Triangle Base Lenght",hint_text="Ex. 10",visible=False)
    triangle_height = ft.TextField(label="Enter Triangle Height",hint_text="Ex. 10",visible=False)

    result_text = ft.Text(value="Enter values to calculate.", size=16,)
    depth_top =ft.TextField(label="Depth (from top)",visible=True)
    Angle = ft.TextField(label="Angle of the gate",visible = True)

    material_dropdown = ft.Dropdown(
        label="Gate Material",
        options=[
            ft.dropdown.Option(key="250", text="Structural Steel A36 (250 MPa)"),
            ft.dropdown.Option(key="276", text="Aluminum 6061-T6 (276 MPa)"),
            ft.dropdown.Option(key="215", text="Stainless Steel 304 (215 MPa)"),
            ft.dropdown.Option(key="300 ", text="Wrought Iron(300 MPa)"),
            ft.dropdown.Option(key="200", text="Cast Iron (Gray Iron, Class 30)(200 MPa)"),
            ft.dropdown.Option(key="470", text="High-Strength Steel (S355)(470 MPa)"),
        ],
        value="250",
    )
    support_area = ft.TextField(label="Support Area (cm²)", hint_text="Ex. 50", visible=True)



    #the math
    def run_calculation(e):
        try:
            density = float(custom_density.value) if custom_density.value !="" else float(fluid_dropdown.value)
            selected_shape = shape_dropdown.value
            depth = float(depth_top.value)
            angle = float(Angle.value)
            if selected_shape == "Rectangular":
                w = float(rectangle_width.value)
                h = float(rectangle_height.value)
                area = float(w * h)
                I_xc = float(((h**3)*w)/12)
                D_center = float(h/2)

            elif selected_shape == "Circular":
                r = float(Circle_Radii.value)
                area = float(math.pi*(r**2))
                I_xc = float(((math.pi)*(r**4))/4)
                D_center = r

            elif selected_shape == "Triangular":
                h = float(triangle_height.value)
                b = float(triangle_base.value)
                area = float(0.5*b*h)
                I_xc = float(((b)*(h**3))/36)
                D_center = float(h/3)
            angle_rad = math.radians(angle)
            h_c = depth +(D_center *math.sin(angle_rad))
            force_resultant = density * 9.81 * h_c * area
            force_x = force_resultant * math.sin((angle_rad))
            force_y = force_resultant * math.cos((angle_rad))
            force_resultant_KN = force_resultant / 1000
            force_x_KN = force_x / 1000
            force_y_KN = force_y / 1000
            if angle == 0:
                y_p_str = "Horizontal gate"
            else:
                y_c = h_c / math.sin((angle_rad))
                y_p = y_c + (I_xc /(y_c * area) )
                y_p_str =f"{y_p:,.3f} m"
            
            material_status_str = ""
            if support_area.value != "":
                cross_section_m2 = float(support_area.value) / 10000 

                if cross_section_m2 > 0:
                    stress_mpa = (force_resultant / cross_section_m2) / 1_000_000
                    yield_point = float(material_dropdown.value)
                    
                    if stress_mpa >= yield_point:
                        status = f"YIELDS (Fails) - Stress hits {stress_mpa:,.4f} MPa"
                    else:
                        status = f"STANDS (Safe) - Max stress is {stress_mpa:,.4f} MPa"
                    
                    material_status_str = f"\n\nMaterial Check: {status}"
                else:
                    material_status_str = "\n\nMaterial Check: Area must be > 0"
            
            result_text.value= (
            f"Total Resultant Force = {force_resultant_KN:.2f}KN\n"
            f"Force Acting Upon X-axis = {force_x_KN:.2f}KN\n "
            f"Force Acting Upon Y-axis = {force_y_KN:.2f}KN\n"
            f"Center of pressure = {y_p_str}\n"
            f"Force Direction: {90-angle} degrees from Horizontal"
            f"{material_status_str}"
        )
            result_text.color = ft.Colors.GREEN_700
        except ValueError:
            result_text.value = "Error:please check your inputs that they are NUMBERS"
            result_text.color = ft.Colors.RED_500
        except ZeroDivisionError:
            result_text.value = "Error:Cannot divide by zero يا هندسه"
            result_text.color = ft.Colors.RED_500
        app_page.update()
    Calc_button = ft.Button(content=ft.Text("Calculate"),on_click=run_calculation)

    #showing the text inputs once chosen 
    def update_ui(e):
        selected = shape_dropdown.value
        rectangle_height.visible = False
        rectangle_width.visible = False
        Circle_Radii.visible = False
        triangle_base.visible = False
        triangle_height.visible = False
        if selected == "Rectangular":
            rectangle_height.visible = True
            rectangle_width.visible = True
        elif selected == "Circular":
            Circle_Radii.visible = True
        elif selected == "Triangular":
            triangle_base.visible = True
            triangle_height.visible = True
        app_page.update()
#Ui
    page.add(

        ft.Text("Hydrostatic Gate Force Calculator", size=24, weight=ft.FontWeight.BOLD),
        ft.Divider(height=20,color=ft.Colors.GREY_300),
        ft.Text("1. Fluid Properties",size=16, weight=ft.FontWeight.BOLD),
        ft.Row([fluid_dropdown, custom_density],wrap=True),
        ft.Row([material_dropdown, support_area], wrap=True),
        ft.Divider(height=10,color=ft.Colors.TRANSPARENT),
        ft.Text("2. Gate Geometry & Environment",size=16, weight=ft.FontWeight.BOLD),
        shape_dropdown,
        ft.Row([rectangle_width, rectangle_height, Circle_Radii],wrap=True),
        ft.Row([triangle_base, triangle_height],wrap=True),
        ft.Row([depth_top, Angle],wrap=True),
        ft.Divider(height=20,color=ft.Colors.TRANSPARENT),
        Calc_button,
        ft.Divider(height=10,color=ft.Colors.TRANSPARENT),
        ft.Card(
            content=ft.Container(
                content=result_text,
                padding=20
            ),
            elevation=4
        )
    )
ft.run(main)